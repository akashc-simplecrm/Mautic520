# Plugin: SimplecrmCampaignBundle

# Version 
5.1.1

# Overview:
This plugin allows to send Campaign Activity Tracking

    
## Synopsis

This plugin allows to send Campaign Activity Tracking


## Installation

- Create a new "SimplecrmCampaignBundle" folder in the plugins folder
- Copy the plugins files into the SimplecrmCampaignBundle folder.
- Go to the Configuration -> Plugins Settings, in Mautic web interface.
- Click on Install/Upgrade Plugins.
- The plugin should now be available for configuration.

## Tests



# Changelogs

# V5.2.0🚀

## New Features
* 

## Enhancements and Improvements
* Supports PHP 8.2
* Compatable with Mautic v5.2.x


## Bug Fixes
* 